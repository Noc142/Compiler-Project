#ifndef SCANNER_H
#define SCANNER_H

enum nonterminal{
Program=1001, ExtDefList,ExtDef,ExtDecList,
Specifier,StructSpecifier,OptTag,Tag,
VarDec,FunDec,VarList,ParamDec,
CompSt,StmtList,Stmt,
DefList,Def,DecList,Dec,
Exp,Args
};

#endif
